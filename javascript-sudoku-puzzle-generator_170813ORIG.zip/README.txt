A Pen created at CodePen.io. You can find this one at https://codepen.io/pavlovsk/pen/XmjPOE.

 In this demo, backtracking algorithm is used for generating the sudoku. Difficulty and solvability is totally random as I randomly left a number of hints from a full-filled board.